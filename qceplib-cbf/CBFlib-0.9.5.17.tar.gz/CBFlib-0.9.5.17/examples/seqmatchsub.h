/*
 *  seqmatchsub.h
 *  
 *
 *  Created by Herbert J. Bernstein on 2/24/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

int seqsubmatch(const char * seq1, const int * resn1, int * resflg1, int seqlen1,
                const char * seq2, const int * resn2, int * resflg2, int seqlen2) {
    
    int stutter = 0;
    
}

