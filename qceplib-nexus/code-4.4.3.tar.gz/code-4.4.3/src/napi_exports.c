/*
 * $Id$
 *
 *  __stdcall uppercase aliases for Windows
 */

#include "napi.h"

#define CALL_MODE	__stdcall

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "napi_exports.h"

#ifdef __cplusplus
}
#endif /* __cplusplus */
