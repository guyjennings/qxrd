/************************************************************* 
 * 
 * Include file - 'mcgill.h'
 *
 * For use with the McGill Super Duper random number package.
 *
 ************************************************************/

void rstart(long, long);
long iuni(void);
long ivni (void);
double uni (void);
double vni (void);
